﻿namespace P01_BillsPaymentSystem.Data.Models
{
    public enum PaymentType
    {
        BankAccount,
        CreditCard

    }
}