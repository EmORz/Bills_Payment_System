﻿using System;

namespace P01_BillsPaymentSystem.Data
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-CP2NEHV\SQLEXPRESS;Database=PaymentSystem;Integrated Security=True";
    }
}
