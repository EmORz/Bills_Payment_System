﻿using System;

namespace BillsPaymentSystem.Data
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-CP2NEHV\SQLEXPRESS;Database=PaymentSystem_V1;Integrated Security=True";
    }
}
