﻿using System;
using BillsPaymentSystem.App.Core.Commands.Contracts;
using BillsPaymentSystem.Data;

namespace BillsPaymentSystem.App.Core.Commands
{
    public class ExitCommands : ICommands
    {
        private readonly BillsPaymentSystemContext context;

        public ExitCommands(BillsPaymentSystemContext context)
        {
            this.context = context;
        }
        public string Execute(string[] args)
        {
            var command = args[0];
            return command;
        }
    }
}